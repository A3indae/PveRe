﻿using LabApi;
using LabApi.Events.Handlers;
using LabApi.Features;
using LabApi.Features.Console;
using LabApi.Loader.Features.Plugins;
using LabApi.Loader.Features.Plugins.Enums;
using System;

public class MainPlugin : Plugin
{
    public override string Name { get; } = "Pveplugin";
    public override string Description { get; } = "AI와 싸우는 모드";
    public override string Author { get; } = "A3indae";
    public override Version Version { get; } = new Version(2, 0);
    public override Version RequiredApiVersion { get; } = new Version(LabApiProperties.CompiledVersion);
    public override LoadPriority Priority { get; } = LoadPriority.High;

    public override void Enable()
    {
        ServerEvents.RoundStarting += ModeHandler.LoadMode;
        ServerEvents.RoundEnding += ModeHandler.KillMode;
    }
    public override void Disable()
    {
        ModeHandler.KillMode();
        ServerEvents.RoundStarting -= ModeHandler.LoadMode;
        ServerEvents.RoundEnding -= ModeHandler.KillMode;
    }
}