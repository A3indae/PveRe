﻿using LabApi;
using LabApi.Events.Arguments.ServerEvents;
using LabApi.Features.Console;

public static class ModeHandler
{
    private static bool started = false;
    private static Mode currentMode = null;

    public static void LoadMode(RoundStartingEventArgs _)
    {
        KillMode();
        started = true;
        currentMode = new Modes.PVE.ModeMain();
        currentMode.StartMode();
    }
    public static void KillMode()
    {
        if (!started) return;
        started = false;
        if (currentMode != null)
        {
            currentMode.EndMode();
            currentMode = null;
        }
    }
    public static void KillMode(RoundEndingEventArgs _) => KillMode();//오버로딩
}