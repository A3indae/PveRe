﻿using LabApi.Features.Console;
using System.Collections.Generic;
using UnityEngine;
using MEC;
using LabApi.Features.Wrappers;
using PlayerRoles;
using UnityEngine.AI;
using MapGeneration;
using System.Linq;
using LabApi.Features.Enums;
using NetworkManagerUtils.Dummies;

namespace Modes.PVE//Modes.PVE.ModeMain();
{
    public class ModeMain : Mode //PVE모드가 가장 먼저 호출되는곳
    {
        private bool started = false;
        private bool ended = false;

        private Dictionary<int, GameObject> enemies = new Dictionary<int, GameObject>();
        private int cursor = 0;

        private CoroutineHandle runningCoroutine;
        private Modes.PVE.Config config = new Modes.PVE.Config();
        private Modes.PVE.Econnector econnector = new Modes.PVE.Econnector();
        NavMeshDataInstance navMesh;

        private List<Vector3> enemySpawnPositions = new List<Vector3>();
        private Vector3 gateBposition;
        public override void StartMode()//라운드시작
        {
            if (started || ended) return;
            started = true;

            //이벤트연결
            LabApi.Events.Handlers.PlayerEvents.Hurting += econnector.OnHurtingEvent;
            LabApi.Events.Handlers.ServerEvents.WaveRespawning += econnector.OnWaveRespawning;
            LabApi.Events.Handlers.ServerEvents.CassieAnnouncing += econnector.OnCassie;

            //진행
            Round.IsLocked = true;
            runningCoroutine = Timing.RunCoroutine(DoRound());

            foreach (Door door in Map.Doors)
            {
                if (door.Zone != FacilityZone.Entrance) continue;
                door.Lock(reason: Interactables.Interobjects.DoorUtils.DoorLockReason.NoPower, enabled: true);
                door.IsOpened = (door.DoorName != DoorName.EzIntercom);
            }
            foreach (Room room in Map.Rooms)
            {
                if (room.Name == RoomName.EzGateA || room.Name == RoomName.EzRedroom || room.Name == RoomName.EzCollapsedTunnel || room.Name == RoomName.EzEvacShelter)
                {
                    if (room.Name == RoomName.EzCollapsedTunnel || room.Name == RoomName.EzEvacShelter)
                    {
                        enemySpawnPositions.Add(room.Doors.First().Position + Vector3.up);
                    }
                    else
                    {
                        enemySpawnPositions.Add(room.Position + Vector3.up);
                    }
                }
                if (room.Name == RoomName.EzGateB)
                {
                    gateBposition = room.Position+Vector3.up;
                }
                if (room.Name == RoomName.HczCheckpointToEntranceZone)
                {
                    foreach(Door door in room.Doors)
                    {
                        door.IsOpened = false;
                    }
                }

            }
            foreach (Elevator elevator in Map.Elevators) elevator.LockAllDoors();
            foreach (Pickup pickup in Map.Pickups) pickup.Destroy();

            navMesh.Remove();
            var bounds = new Bounds(Vector3.zero, new Vector3(2000, 2000, 2000));
            var markups = new List<NavMeshBuildMarkup>();
            var sources = new List<NavMeshBuildSource>();

            int maskInvCol = LayerMask.GetMask("Default", "InvisibleCollider");
            NavMeshBuilder.CollectSources(bounds, maskInvCol, NavMeshCollectGeometry.PhysicsColliders, 0, markups, sources);

            var settings = NavMesh.CreateSettings();
            settings.agentRadius = .17f;
            settings.agentHeight = 0.83f;
            settings.agentClimb = .21f;
            settings.agentSlope = 45;
            //settings.minRegionArea = .2f; 이거 뭐하는건진 모르겠는데 일단 없으니까 작동 잘해서 주석처리함

            var data = NavMeshBuilder.BuildNavMeshData(settings, sources, bounds, Vector3.zero, Quaternion.identity);
            navMesh = NavMesh.AddNavMeshData(data);
        }
        public override void EndMode()//라운드종료
        {
            if (ended || !started) return;
            ended = true;
            started = false;

            //이벤트연결해제
            LabApi.Events.Handlers.PlayerEvents.Hurting -= econnector.OnHurtingEvent;
            LabApi.Events.Handlers.ServerEvents.WaveRespawning -= econnector.OnWaveRespawning;
            LabApi.Events.Handlers.ServerEvents.CassieAnnouncing -= econnector.OnCassie;
            econnector = null;

            //정리
            Timing.KillCoroutines(runningCoroutine);
            foreach (GameObject obj in enemies.Values)
            {
                obj.GetComponent<Modes.PVE.Enemy>().RemoveEnemy();
            }
            enemies.Clear();
            navMesh.Remove();
            DummyUtils.DestroyAllDummies();
            LabApi.Features.Console.Logger.Warn("모드종료");
        }
        private IEnumerator<float> DoRound()//라운드진행
        {
            yield return Timing.WaitForSeconds(3);
            for (int wave = 0; wave < config.WaveInfos.Length; wave++)
            {
                ReviveAllPlayers(out int playerCount);
                Modes.PVE.Config.WaveInfo waveInfo = config.WaveInfos[wave];

                Vector3 SupplySpawnPosition = gateBposition;//보급품 생성
            foreach (Player player in Player.List)
                {
                    if (!IsValidPlayer(player)) continue;
                    player.SendHint(text: $"보급품 스폰됨(GateB)", duration: 10);
                }
                foreach (Config.SupplySpawnInfo spawnInfo in waveInfo.SupplySpawnInfos)
                {
                    for (int i = 0; i < (int)(spawnInfo.Amount + playerCount * spawnInfo.Amount * config.SupplyMultiplyPerPlayers); i++)
                    {
                        Pickup pickup = Pickup.Create(spawnInfo.Type, SupplySpawnPosition);
                        pickup.Spawn();
                    }
                }
                for (int timer = waveInfo.IntermissionTime; timer >= 0; timer--)//타이머
                {
                    Server.SendBroadcast(message: timer.ToString(), duration: 1);
                    yield return Timing.WaitForSeconds(1);
                }
                Server.SendBroadcast(message: waveInfo.BCtext, duration: 10);
                foreach (Config.EnemySpawnInfo spawnInfo in waveInfo.EnemySpawnInfos)//적 스폰
                {
                    for (int i = 0; i < (int)(spawnInfo.Amount + playerCount * spawnInfo.Amount * config.EnemyMultiplyPerPlayers); i++)
                    {
                        Enemy enemy = CreateEnemy(spawnInfo.EnemyName, out GameObject enemyContainer);
                        enemies.Add(cursor, enemyContainer);
                        enemy.Id = cursor;
                        enemy.container = enemyContainer;
                        enemy.enemies = enemies;
                        cursor++;
                        enemy.Initlize(spawnInfo.EnemyName, enemySpawnPositions.RandomItem());
                        yield return Timing.WaitForSeconds(0.6f);
                    }
                }
                while (enemies.Count > 0 && GetAlivePlayerCount() > 0) yield return Timing.WaitForSeconds(5);
                if (GetAlivePlayerCount() <= 0)
                {
                    Round.IsLocked = false;
                    EndMode();
                }
                DummyUtils.DestroyAllDummies();
            }
            Server.SendBroadcast(message: "vic".ToString(), duration: 1);
            Round.IsLocked = false;
            EndMode();
        }
        private void ReviveAllPlayers(out int playerCount)
        {
            playerCount = -1;
            foreach (Player player in Player.List)
            {
                if (!IsValidPlayer(player)) continue;
                playerCount++;
                if (IsAlivePlayer(player)) continue;
                player.SetRole(RoleTypeId.NtfSergeant, RoleChangeReason.RemoteAdmin);
                Timing.CallDelayed(0.5f, () =>
                {
                    if (player == null || player.Role != RoleTypeId.NtfSergeant) return;
                    player.ClearInventory();
                    player.Position = gateBposition;
                    player.AddItem(ItemType.GunCOM18, InventorySystem.Items.ItemAddReason.AdminCommand);
                    player.AddAmmo(ItemType.Ammo9x19, 40);
                });
            }
        }
        private Modes.PVE.Enemy CreateEnemy(string enemyName, out GameObject enemyContainer)//C#7.3  스폰관리
        {
            enemyContainer = new GameObject("enemyContainer");
            Enemy enemy;
            switch (enemyName)
            {
                case "Lancer": enemy = enemyContainer.AddComponent<Enemies.Lancer>(); break;
                case "Rifleman": enemy = enemyContainer.AddComponent<Enemies.Rifleman>(); break;
                case "Pyromancer": enemy = enemyContainer.AddComponent<Enemies.Pyromancer>(); break;
                default:  enemy = enemyContainer.AddComponent<Enemies.Scout>(); break;
            }
            return enemy;
        }
        private int GetAlivePlayerCount()//있긴 한데 안씀
        {
            int count = 0;
            foreach (Player player in Player.List)
            {
                if (!IsValidPlayer(player)) continue;
                if (player.Role != RoleTypeId.NtfSergeant) continue;
                count++;
            }
            return count;
        }
        private bool IsValidPlayer(Player player)
        {
            if (player == null) return false;
            if (player.UserId == "ID_Dedicated" || player.UserId == "ID_Dummy" || player.IsNpc) return false;
            return true;
        }
        private bool IsAlivePlayer(Player player)
        {
            if (player == null) return false;
            if (player.UserId == "ID_Dedicated" || player.UserId == "ID_Dummy" || player.IsNpc) return false;
            if (player.Role != RoleTypeId.NtfSergeant) return false;
            return true;
        }
    }
}