﻿using System.Collections.Generic;

namespace Modes.PVE
{
    public class Config
    {
        public float EnemyMultiplyPerPlayers { get; } = 0.25f;//플레이어당 유닛 배율(2인 이상에서만 유효)
        public float SupplyMultiplyPerPlayers { get; } = 0.25f;//플레이어당 보급 해율(2인 이상에서만 유효)

        public WaveInfo[] WaveInfos { get; } = new WaveInfo[6]//웨이브 구조
        {
            new WaveInfo(
                    intermissionTime: 15,
                    bcText: "Wave 1",
                    supplySpawnInfos: new List<SupplySpawnInfo>
                    {
                        new SupplySpawnInfo(ItemType.Painkillers, 4),
                        new SupplySpawnInfo(ItemType.Adrenaline, 2),
                    },
                    enemySpawnInfos: new List<EnemySpawnInfo>
                    {
                        new EnemySpawnInfo("Scout", 4),
                    }
            ),
            new WaveInfo(
                    intermissionTime: 15,
                    bcText: "Wave 2",
                    supplySpawnInfos: new List<SupplySpawnInfo>
                    {
                        new SupplySpawnInfo(ItemType.ArmorLight, 1),
                        new SupplySpawnInfo(ItemType.Medkit, 3),
                        new SupplySpawnInfo(ItemType.Ammo9x19, 5),
                    },
                    enemySpawnInfos: new List<EnemySpawnInfo>
                    {
                        new EnemySpawnInfo("Scout", 6),
                        new EnemySpawnInfo("Lancer", 1),
                    }
            ),
            new WaveInfo(
                    intermissionTime: 15,
                    bcText: "Wave 3",
                    supplySpawnInfos: new List<SupplySpawnInfo>
                    {
                        new SupplySpawnInfo(ItemType.GunCrossvec, 2),
                        new SupplySpawnInfo(ItemType.ArmorCombat, 2),
                        new SupplySpawnInfo(ItemType.Medkit, 3),
                        new SupplySpawnInfo(ItemType.Adrenaline, 3),
                        new SupplySpawnInfo(ItemType.Ammo9x19, 8),
                    },
                    enemySpawnInfos: new List<EnemySpawnInfo>
                    {
                        new EnemySpawnInfo("Scout", 4),
                        new EnemySpawnInfo("Lancer", 2),
                        new EnemySpawnInfo("Rifleman", 1),
                    }
            ),
            new WaveInfo(
                    intermissionTime: 15,
                    bcText: "Wave 4",
                    supplySpawnInfos: new List<SupplySpawnInfo>
                    {
                        new SupplySpawnInfo(ItemType.Medkit, 5),
                        new SupplySpawnInfo(ItemType.Adrenaline, 3),
                        new SupplySpawnInfo(ItemType.Ammo9x19, 10),
                        new SupplySpawnInfo(ItemType.GunE11SR, 2),
                        new SupplySpawnInfo(ItemType.ArmorHeavy, 1),
                        new SupplySpawnInfo(ItemType.Ammo556x45, 5),
                    },
                    enemySpawnInfos: new List<EnemySpawnInfo>
                    {
                        new EnemySpawnInfo("Lancer", 2),
                        new EnemySpawnInfo("Scout", 2),
                        new EnemySpawnInfo("Rifleman", 3),
                    }
            ),
            new WaveInfo(
                    intermissionTime: 15,
                    bcText: "Wave 5",
                    supplySpawnInfos: new List<SupplySpawnInfo>
                    {
                        new SupplySpawnInfo(ItemType.Medkit, 3),
                        new SupplySpawnInfo(ItemType.Adrenaline, 3),
                        new SupplySpawnInfo(ItemType.SCP500, 1),
                        new SupplySpawnInfo(ItemType.SCP268, 1),
                        new SupplySpawnInfo(ItemType.Ammo9x19, 10),
                    },
                    enemySpawnInfos: new List<EnemySpawnInfo>
                    {
                        new EnemySpawnInfo("Scout", 5),
                        new EnemySpawnInfo("Lancer", 5),
                        new EnemySpawnInfo("Pyromancer", 2),
                    }
            ),
            new WaveInfo(
                    intermissionTime: 15,
                    bcText: "<color=red>Wave 6</color>",
                    supplySpawnInfos: new List<SupplySpawnInfo>
                    {
                        new SupplySpawnInfo(ItemType.Medkit, 3),
                        new SupplySpawnInfo(ItemType.Adrenaline, 3),
                        new SupplySpawnInfo(ItemType.SCP500, 1),
                        new SupplySpawnInfo(ItemType.SCP268, 1),
                        new SupplySpawnInfo(ItemType.GunE11SR, 2),
                        new SupplySpawnInfo(ItemType.ArmorHeavy, 1),
                        new SupplySpawnInfo(ItemType.Ammo556x45, 10),
                        new SupplySpawnInfo(ItemType.Ammo9x19, 10),
                    },
                    enemySpawnInfos: new List<EnemySpawnInfo>
                    {
                        new EnemySpawnInfo("Monster", 1),
                        new EnemySpawnInfo("Rifleman", 5),
                        new EnemySpawnInfo("Pyromancer", 1),
                    }
            ),
        };
        //타입
        public class EnemySpawnInfo
        {
            public string EnemyName { get; }
            public float Amount { get; }
            public EnemySpawnInfo(string enemyType, float amount)
            {
                EnemyName = enemyType;
                Amount = amount;
            }
        }
        public class SupplySpawnInfo
        {
            public ItemType Type { get; }
            public float Amount { get; }

            public SupplySpawnInfo(ItemType type, float amount)
            {
                Type = type;
                Amount = amount;
            }
        }
        public class WaveInfo
        {
            public List<EnemySpawnInfo> EnemySpawnInfos { get; }
            public int IntermissionTime { get; }
            public List<SupplySpawnInfo> SupplySpawnInfos { get; }

            public string BCtext { get; }

            public WaveInfo(
                List<EnemySpawnInfo> enemySpawnInfos,
                int intermissionTime,
                List<SupplySpawnInfo> supplySpawnInfos,
                string bcText)
            {
                IntermissionTime = intermissionTime;
                SupplySpawnInfos = supplySpawnInfos;
                EnemySpawnInfos = enemySpawnInfos;
                BCtext = bcText;
                
            }
        }
    }
}
