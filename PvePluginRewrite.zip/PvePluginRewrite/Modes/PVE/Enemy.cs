﻿using CentralAuth;
using CustomPlayerEffects;
using LabApi.Features.Wrappers;
using Mirror;
using NetworkManagerUtils.Dummies;
using PlayerRoles;
using PlayerStatsSystem;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using LabApi;

namespace Modes.PVE
{
    public class Enemy : MonoBehaviour
    {
        public int Id { get; set; }
        public Dictionary<int, GameObject> enemies;
        public GameObject container;

        protected bool removed = false;
        protected ReferenceHub hub;
        protected Player selfPlayer;
        public virtual void Initlize(string enemyName, Vector3 spawnPos)
        {
            hub = DummyUtils.SpawnDummy(enemyName);
            hub.authManager.syncMode = (SyncMode)ClientInstanceMode.Dummy;
            hub.playerStats.OnThisPlayerDied += RemoveEnemy;
            selfPlayer = Player.Get(hub);
        }
        public void RemoveEnemy(DamageHandlerBase _) => RemoveEnemy();
        public virtual void RemoveEnemy()
        {
            LabApi.Features.Console.Logger.Warn("base.사망");
            selfPlayer.ClearInventory();
            hub.playerStats.OnThisPlayerDied -= RemoveEnemy;
            if (enemies != null && enemies.TryGetValue(Id, out GameObject gameObject) && gameObject != null)
            {
                enemies.Remove(Id);
            }
            GameObject.Destroy(container);
        }
        protected virtual Player GetClosestPlayer()//기본적으로 268쓰면 인식못함
        {
            if (removed) return null;

            float bestDistance = 100000;
            Player best = null;
            foreach (Player player in Player.List)
            {
                if (!IsAlivePlayer(player)) continue;
                if (player.HasEffect<CustomPlayerEffects.Invisible>()) continue;
                float distance = (player.Position - hub.transform.position).magnitude;
                if (distance < bestDistance)
                {
                    bestDistance = distance;
                    best = player;
                }
            }
            return best;
        }

        protected Vector3[] GetPath(Vector3 target)
        {
            if (!NavMesh.SamplePosition(hub.transform.position, out var startHit, 25f, NavMesh.AllAreas))
            {
                LabApi.Features.Console.Logger.Debug("시작점이 NavMesh 위가 아님");
                LabApi.Features.Console.Logger.Debug(hub.transform.position.ToString());
                return null;
            }
            if (!NavMesh.SamplePosition(target, out var targetHit, 25f, NavMesh.AllAreas))
            {
                LabApi.Features.Console.Logger.Debug("목표지점이 NavMesh 위가 아님");
                return null;
            }

            int areaMask = NavMesh.AllAreas;
            var path = new NavMeshPath();
            if (NavMesh.CalculatePath(startHit.position, targetHit.position, areaMask, path))
            {
                if (path.status == NavMeshPathStatus.PathComplete) return path.corners; // 경로 지점들 반환
            }

            return null;//아님말고
        }
        protected bool IsAlivePlayer(Player player)
        {
            if (player == null) return false;
            if (player.UserId == "ID_Dedicated" || player.UserId == "ID_Dummy" || player.IsNpc) return false;
            if (player.Role != RoleTypeId.NtfSergeant) return false;
            return true;
        }
    }
}