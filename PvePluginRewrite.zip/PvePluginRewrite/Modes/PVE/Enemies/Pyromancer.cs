﻿using UnityEngine;
using LabApi;
using LabApi.Features.Console;
using System.Collections.Generic;
using LabApi.Features.Wrappers;
using MapGeneration;
using MEC;
using PlayerRoles.FirstPersonControl;
using RelativePositioning;
using InventorySystem.Items.Firearms;
using InventorySystem.Items.Firearms.Modules;
using InventorySystem.Items;
using PlayerStatsSystem;
using InventorySystem;
using InventorySystem.Items.Firearms.Attachments;
using NetworkManagerUtils.Dummies;
using InventorySystem.Items.MicroHID;
using Christmas.Scp2536;

namespace Modes.PVE.Enemies
{
    public class Pyromancer : Modes.PVE.Enemy
    {
        //pathfind관련
        private bool followEnabled = true;
        private bool finished = false;
        private float followStartTime = 0;
        private Vector3 targetPosition = Vector3.zero;


        private Player lookPlayer;
        private bool firing = false;

        //management
        IFpcRole fpc;
        private CoroutineHandle followAI;
        private CoroutineHandle lookAI;
        private InventorySystem.Items.MicroHID.MicroHIDItem firearm;
        public override void Initlize(string enemyName, Vector3 spawnPos)
        {
            base.Initlize(enemyName, spawnPos);
            selfPlayer.SetRole(PlayerRoles.RoleTypeId.ChaosConscript, PlayerRoles.RoleChangeReason.RemoteAdmin);
            selfPlayer.Position = spawnPos + new Vector3(Random.value*0.5f,0, Random.value*0.5f);
            selfPlayer.EnableEffect<CustomPlayerEffects.SpawnProtected>(1, 5, true);//스폰무적
            //selfPlayer.EnableEffect<CustomPlayerEffects.Slowness>(30, 0, false);//슬로우

            if (selfPlayer.RoleBase is IFpcRole Ifpc)//fpc구하기
            {
                fpc = Ifpc;
            }

            hub.playerStats.GetModule<HealthStat>().MaxValue = 600f;
            hub.playerStats.GetModule<HealthStat>().CurValue = 600f;

            selfPlayer.ClearInventory();
            selfPlayer.Inventory.ServerAddItem(ItemType.ArmorHeavy, ItemAddReason.AdminCommand);
            ItemBase item = selfPlayer.Inventory.ServerAddItem(ItemType.MicroHID, ItemAddReason.AdminCommand);
            selfPlayer.Inventory.ServerSelectItem(item.ItemSerial);
            firearm = item as InventorySystem.Items.MicroHID.MicroHIDItem;
            firearm.GrantAmmoReward();

            followAI = Timing.RunCoroutine(FollowAI());
            lookAI = Timing.RunCoroutine(LookAI());
        }
        public override void RemoveEnemy()
        {
            if (removed) return;
            removed = true;

            Timing.KillCoroutines(followAI);
            Timing.KillCoroutines(lookAI);
            LabApi.Features.Console.Logger.Warn("사망");
            base.RemoveEnemy();

        }
        private void Update()
        {
            Vector3 direction = targetPosition - selfPlayer.Position;//움직이는거
            direction.y = 0;
            if (direction.magnitude > 0)
            {
                if (followEnabled) { fpc.FpcModule.Motor.ReceivedPosition = new RelativePosition(selfPlayer.Position + direction.normalized); }
                else { fpc.FpcModule.Motor.ReceivedPosition = new RelativePosition(selfPlayer.Position - direction.normalized); }
            }
            if (direction.magnitude < 0.5 || direction.magnitude > 10)
            {
                finished = true;
            }

            Vector3 lookPlayerPosition;//처다보기&쏘기
            if (lookPlayer == null) { lookPlayerPosition = Vector3.zero; }
            else { lookPlayerPosition = lookPlayer.Position; }
            Vector3 lookDirection = lookPlayerPosition - selfPlayer.Position;

            if (lookDirection.magnitude > 0)
            {
                fpc.FpcModule.MouseLook.LookAtDirection(lookDirection.normalized);
                float magnitude = lookDirection.magnitude;
                if (firing)
                {
                    if (magnitude > 18)
                    {
                        firing = false;
                        Server.RunCommand($"/dummy action {selfPlayer.PlayerId}. MicroHID_(#{firearm.ItemSerial}) Shoot->Release");
                    }
                }
                else
                {
                    if (magnitude <= 12)
                    {
                        bool shootCast = Physics.Raycast(selfPlayer.Position, lookDirection.normalized, out RaycastHit _, maxDistance: lookDirection.magnitude, layerMask: LayerMask.GetMask("Default", "Door"), queryTriggerInteraction: QueryTriggerInteraction.Ignore);
                        if (magnitude <= 5 || !shootCast)
                        {
                            firing = true;
                            Server.RunCommand($"/dummy action {selfPlayer.PlayerId}. MicroHID_(#{firearm.ItemSerial}) Shoot->Hold");
                        }
                    }
                }
            }
        }
        private IEnumerator<float> LookAI()
        {
            while (true)
            {
                firearm.EnergyManager.ServerSetEnergy(firearm.ItemSerial, 100);
                Player closestPlayer = GetClosestPlayer();
                if (closestPlayer == null)
                {
                    lookPlayer = null;
                    yield return Timing.WaitForSeconds(0.5f);
                    continue;
                }
                lookPlayer = closestPlayer;
                if ((selfPlayer.Position - closestPlayer.Position).magnitude < 1) followEnabled = false; else followEnabled = true;
                yield return Timing.WaitForSeconds(0.5f);
                continue;
            }
        }
        private IEnumerator<float> FollowAI()
        {
            while (true)
            {
                Player closestPlayer = GetClosestPlayer();
                if (closestPlayer == null)
                {
                    yield return Timing.WaitForSeconds(0.5f);
                    continue;
                }
                Vector3[] paths = GetPath(closestPlayer.Position);
                if (paths == null)
                {
                    yield return Timing.WaitForSeconds(0.5f);
                    continue;
                }
                bool c = true;
                foreach (Vector3 pathPosition in paths)
                {
                    if (c) { c = false; continue; }
                    targetPosition = pathPosition;
                    followStartTime = Time.time;
                    finished = false;
                    while (!finished && followEnabled && Time.time - followStartTime <= 1.6) { yield return Timing.WaitForSeconds(0.2f); }
                    if (Time.time - followStartTime > 1.6) break;
                }
                yield return Timing.WaitForSeconds(0.5f);
                continue;
            }
        }
    }
}
