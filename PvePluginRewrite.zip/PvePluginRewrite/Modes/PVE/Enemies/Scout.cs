﻿using UnityEngine;
using LabApi;
using LabApi.Features.Console;
using System.Collections.Generic;
using LabApi.Features.Wrappers;
using MapGeneration;
using MEC;
using PlayerRoles.FirstPersonControl;
using RelativePositioning;
using InventorySystem.Items.Firearms;
using InventorySystem.Items.Firearms.Modules;
using InventorySystem.Items;
using PlayerStatsSystem;
using InventorySystem;

namespace Modes.PVE.Enemies
{
    public class Scout : Modes.PVE.Enemy
    {
        //pathfind관련
        private bool followEnabled = true;
        private bool finished = false;
        private float followStartTime = 0;
        private Vector3 targetPosition = Vector3.zero;


        private Player lookPlayer;

        //management
        IFpcRole fpc;
        private CoroutineHandle followAI;
        private CoroutineHandle lookAI;
        private bool canShoot = true;
        private Firearm firearm;
        private MagazineModule magModule;
        public override void Initlize(string enemyName, Vector3 spawnPos)
        {
            base.Initlize(enemyName, spawnPos);
            selfPlayer.SetRole(PlayerRoles.RoleTypeId.ChaosConscript, PlayerRoles.RoleChangeReason.RemoteAdmin);
            selfPlayer.Position = spawnPos + new Vector3(Random.value*0.5f,0, Random.value*0.5f);
            selfPlayer.EnableEffect<CustomPlayerEffects.SpawnProtected>(1, 3, true);//스폰무적
            selfPlayer.EnableEffect<CustomPlayerEffects.MovementBoost>(50, 0, false);//스폰무적

            if (selfPlayer.RoleBase is IFpcRole Ifpc)//fpc구하기
            {
                fpc = Ifpc;
            }

            hub.playerStats.GetModule<HealthStat>().MaxValue = 80f;
            hub.playerStats.GetModule<HealthStat>().CurValue = 80f;

            selfPlayer.ClearInventory();
            ItemBase item = selfPlayer.Inventory.ServerAddItem(ItemType.GunCOM18, ItemAddReason.AdminCommand);
            selfPlayer.Inventory.ServerSelectItem(item.ItemSerial);
            firearm = item as Firearm;
            firearm.TryGetModule(out MagazineModule magazineModule);
            magModule = magazineModule;

            followAI = Timing.RunCoroutine(FollowAI());
            lookAI = Timing.RunCoroutine(LookAI());
        }
        public override void RemoveEnemy()
        {
            if (removed) return;
            removed = true;

            Timing.KillCoroutines(followAI);
            Timing.KillCoroutines(lookAI);
            LabApi.Features.Console.Logger.Warn("사망");
            base.RemoveEnemy();

        }
        private void Update()
        {
            Vector3 direction = targetPosition - selfPlayer.Position;//움직이는거
            direction.y = 0;
            if (direction.magnitude > 0)
            {
                if (followEnabled) { fpc.FpcModule.Motor.ReceivedPosition = new RelativePosition(selfPlayer.Position + direction.normalized); }
                else { fpc.FpcModule.Motor.ReceivedPosition = new RelativePosition(selfPlayer.Position - hub.transform.forward); }
            }
            if (direction.magnitude < 0.5 || direction.magnitude > 10)
            {
                finished = true;
            }

            Vector3 lookPlayerPosition;//처다보기&쏘기
            if (lookPlayer == null) { lookPlayerPosition = Vector3.zero; }
            else { lookPlayerPosition = lookPlayer.Position; }
            Vector3 lookDirection = lookPlayerPosition - selfPlayer.Position;

            if (lookDirection.magnitude > 0)
            {
                fpc.FpcModule.MouseLook.LookAtDirection(lookDirection.normalized);
                float magnitude = lookDirection.magnitude;
                if (magnitude < 20 && canShoot)
                {
                    bool shootCast = Physics.Raycast(selfPlayer.Position, lookDirection.normalized, out RaycastHit hitInfo, maxDistance: lookDirection.magnitude, layerMask: LayerMask.GetMask("Default", "Door"), queryTriggerInteraction: QueryTriggerInteraction.Ignore);
                    if (!shootCast)
                    {
                        canShoot = false;
                        Server.RunCommand($"/dummy action {selfPlayer.PlayerId}. GunCOM18_(#{firearm.ItemSerial}) Shoot->Click");
                        magModule.ServerSetInstanceAmmo(firearm.ItemSerial, 15);
                        if (lookDirection.magnitude < 3 && followEnabled)
                        {
                            followEnabled = false;
                            Timing.CallDelayed(1f, () => { followEnabled = true; });
                        }
                        Timing.CallDelayed(0.4f, () => { canShoot = true; });
                    }
                }
            }
        }
        private IEnumerator<float> LookAI()
        {
            while (true)
            {
                Player closestPlayer = GetClosestPlayer();
                if (closestPlayer == null)
                {
                    lookPlayer = null;
                    yield return Timing.WaitForSeconds(0.5f);
                    continue;
                }
                lookPlayer = closestPlayer;
                yield return Timing.WaitForSeconds(0.5f);
                continue;
            }
        }
        private IEnumerator<float> FollowAI()
        {
            while (true)
            {
                Player closestPlayer = GetClosestPlayer();
                if (closestPlayer == null)
                {
                    yield return Timing.WaitForSeconds(0.5f);
                    continue;
                }
                Vector3[] paths = GetPath(closestPlayer.Position);
                if (paths == null)
                {
                    yield return Timing.WaitForSeconds(0.5f);
                    continue;
                }
                bool c = true;
                foreach (Vector3 pathPosition in paths)
                {
                    if (c) { c = false; continue; }
                    targetPosition = pathPosition;
                    followStartTime = Time.time;
                    finished = false;
                    while (!finished && followEnabled && Time.time - followStartTime <= 1.6) { yield return Timing.WaitForSeconds(0.2f); }
                    if (Time.time - followStartTime > 1.6) break;
                }
                yield return Timing.WaitForSeconds(0.5f);
                continue;
            }
        }
    }
}
