﻿using InventorySystem.Items;
using InventorySystem.Items.Firearms;
using InventorySystem.Items.Firearms.Attachments;
using InventorySystem.Items.MicroHID.Modules;
using LabApi;
using LabApi.Events;
using LabApi.Events.Arguments.PlayerEvents;
using LabApi.Events.Arguments.ServerEvents;
using LabApi.Features.Wrappers;
using PlayerStatsSystem;

namespace Modes.PVE
{
    public class Econnector
    {
        public void OnHurtingEvent(PlayerHurtingEventArgs ev)
        {
            if (ev.Attacker != null && ev.Attacker.IsDummy)
            {
                if (ev.Player != null && ev.Player.IsDummy) {ev.IsAllowed = false; return;} //팀킬방지
                StandardDamageHandler handler = (StandardDamageHandler)ev.DamageHandler;

                if (ev.Attacker.CurrentItem == null)
                {
                    return;
                }
                switch (ev.Attacker.CurrentItem.Type)
                {
                    case ItemType.GunFSP9: handler.Damage *= 0.02f; break;
                    default: handler.Damage *= 0.1f; break;
                }
            }
            //Firearm firearm = ev.Attacker.CurrentItem.Base as Firearm;
            //LabApi.Features.Console.Logger.Error(firearm.GetCurrentAttachmentsCode());
        }
        public void OnWaveRespawning(WaveRespawningEventArgs ev)
        {
            ev.IsAllowed = false;
        }
        public void OnCassie(CassieAnnouncingEventArgs ev)
        {
            ev.IsAllowed = false;
        }
    }
}