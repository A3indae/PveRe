﻿public abstract class Mode
{
    public abstract void StartMode();
    public abstract void EndMode();
}